# Analyze your Email Inbox to see who sends the most mail

I built this because I had tens of thousands of emails over the course of my accounts lifetime that I had just archived and never deleted. This quick script analyzes your inbox and tells you exactly who the top five senders are.

## Usage

1. Add your username and password to the `config_sample.py` file in the `src/` directory.
2. Run from your command line and wait! (`py src/mail_analyze/mail-analyze.py`)